#include<stdio.h>
int main (void)
{
	printf ("programming is fun. \n");
	printf ("And programming in C is even more fun. \n");
	
	return 0;
}
