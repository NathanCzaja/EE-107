#include<stdio.h>
int main (void)
{
	printf ("programming is fun. \n");
	return 0;
}
