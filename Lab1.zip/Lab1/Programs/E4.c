#include <stdio.h>

int main (void)
{
	int value1, value2, sum;
	
	value1 = 87;
	value2 = 15;
	sum = value1 - value2;
	printf ("The result of %i minus %i is %i\n", value1, value2, sum);
	
	return 0;
}