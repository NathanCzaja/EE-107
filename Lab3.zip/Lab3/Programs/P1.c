// Program to calculate the eighth triangular number

#include <stdio.h>

int main ()
{
	int triangularNumber;
	
	triangularNumber = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8;
	printf ("The eighth triangular number is %i\n", triangularNumber);
	
	return 0;
}