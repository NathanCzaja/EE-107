#include <stdio.h>

void printMessage (void)
{
	printf ("Programming is fun.\n");
}

int main (void)
{
	printMessage ();
	printMessage ();
	
	return 0;
}