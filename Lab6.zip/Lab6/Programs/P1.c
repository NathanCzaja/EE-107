#include <stdio.h>

void printMessage (void)
{
	printf ("Programming is fun.\n");
}

int main (void)
{
	printMessage ();
	
	return 0;
}